<!DOCTYPE html>
<html>
<head>
<title>Hurtownia Owoców</title>
<meta charset="UTF-8">
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
<section id="kontener">
<section id="baner">
Hurtownia Owoców
</section>
<section id="prawy">
<?php
$conn=mysqli_connect('localhost','root','','skupow');
$conn -> query ('SET NAMES utf8');
$conn -> query ('SET CHARACTER_SET utf8_unicode_ci');
$z1=mysqli_query($conn,'SELECT * from firma');
while ($row=mysqli_fetch_array($z1))
{
    echo    "<b>".$row['Nazwa'].'</b>,   '.$row['Miasto'].', '.$row['Adres'].'<br>';
}
$z2=mysqli_query($conn,'SELECT Nazwa, ilosc, Data_zamowienia from owoce, zamowienie where IdFirmy=1 and owoce.IdOwocu=zamowienie.IdOwocu order by Nazwa');
echo "<p>ZAMÓWIENIA FIRMY Nowak&Kowalski</p>";
echo '<table><tr><th>Nazwa owocu</th><th>Ilość w kg</th><th>Data zamówienia</th></tr>';
while($row=mysqli_fetch_array($z2))
{
    echo    "<tr><td>".$row['Nazwa'].'</td><td>'.$row['ilosc'].'</td><td>'.$row['Data_zamowienia'].'</td></tr>';
}
echo "</table>";
mysqli_close($conn);
?>
</section>
<section id="galeria">
<table>
<tr>
<td><img src="pics/czeresnia.jpg" class="obrazki"/></td>
<td><img src="pics/gruszka.jpg" class="obrazki"/></td>
<td><img src="pics/truskawka.jpg" class="obrazki"/></td>
<td><img src="pics/sliwka.jpeg" class="obrazki"/></td>
<td><img src="pics/jagoda.jpg" class="obrazki"/></td>
</tr>
</table>
</section>
</section>
</body>
</html>