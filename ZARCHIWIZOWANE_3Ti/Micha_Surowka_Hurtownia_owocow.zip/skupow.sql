-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2021 at 12:49 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skupow`
--

-- --------------------------------------------------------

--
-- Table structure for table `firma`
--

CREATE TABLE `firma` (
  `Nazwa` varchar(40) COLLATE utf8_polish_ci NOT NULL,
  `Adres` text COLLATE utf8_polish_ci NOT NULL,
  `Miasto` varchar(111) COLLATE utf8_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `firma`
--

INSERT INTO `firma` (`Nazwa`, `Adres`, `Miasto`) VALUES
('Owocki i ten teges', 'Ulica 12', 'Radomsko'),
('MMM OWOCE', 'Łączna 43', ' Lipinki Łużyckie'),
('Pyszniutkie owoce', 'Wawel', 'Kraków');

-- --------------------------------------------------------

--
-- Table structure for table `owoce`
--

CREATE TABLE `owoce` (
  `Nazwa` varchar(40) COLLATE utf8_polish_ci NOT NULL,
  `ilosc` int(11) NOT NULL,
  `Data_zamowienia` date NOT NULL,
  `IdOwocu` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `owoce`
--

INSERT INTO `owoce` (`Nazwa`, `ilosc`, `Data_zamowienia`, `IdOwocu`) VALUES
('Apple', 11, '2021-04-04', 1),
('Grapes', 111, '2021-04-18', 2),
('Banana', 123, '2021-04-07', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zamowienie`
--

CREATE TABLE `zamowienie` (
  `IdFirmy` int(11) NOT NULL,
  `IdOwocu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `zamowienie`
--

INSERT INTO `zamowienie` (`IdFirmy`, `IdOwocu`) VALUES
(1, 1),
(2, 2),
(3, 3),
(1, 2),
(1, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `owoce`
--
ALTER TABLE `owoce`
  ADD PRIMARY KEY (`IdOwocu`),
  ADD UNIQUE KEY `IdOwocu` (`IdOwocu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `owoce`
--
ALTER TABLE `owoce`
  MODIFY `IdOwocu` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
