<html>
<head>
    <title>Zadanie 3 MichałS</title>
</head>
<body>
    <form action="calc3.php" method="POST">
    Pierwsza liczba: <input type=number name="a"/> <br />
    Druga liczba: <input type=number name="b"/> <br />
    Trzecia liczba: <input type=number name="c"/> <br />
    Czwarta liczba: <input type=number name="d"/> <br />
    Piąta liczba: <input type=number name="e"/> <br />
    <input type=submit value="Send" />
    </form>

</body>
</html>