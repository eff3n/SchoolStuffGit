<html>
<head>
    <title>Zadanie 2 MichałS</title>
</head>
<body>
    <form action="calc2.php" method="POST">
    Pierwsza liczba: <input type=number name="a"/> <br />
    Druga liczba: <input type=number name="b"/> <br />
    Trzecia liczba: <input type=number name="c"/> <br />
    <input type=submit value="Send" />
    </form>

</body>
</html>