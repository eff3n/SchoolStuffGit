<?php

$a=$_POST["a"];
$b=$_POST["b"];
$c=$_POST["c"];
$iloczyn=$a*$b*$c;
echo "Iloczyn liczb " . $a . ", " . $b . " i " . $c . " jest równy " . $iloczyn . "<br />";

?>