<?php

$a= $_POST['a'];
$b= $_POST['b'];
$c= $_POST['c'];
print "Funkcja kwadratowa ma postać f(x)= "$a"x^2 + "$b"x +"$c"<br />";

?>
