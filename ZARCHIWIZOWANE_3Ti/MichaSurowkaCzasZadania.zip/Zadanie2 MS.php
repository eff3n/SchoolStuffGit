<?php
echo "<br/>";
echo "<br/>";
setlocale(LC_ALL, 'pl_PL', 'pl', 'Polish_Poland.28592');

echo 'Dzisiaj jest ' . strftime('%A',time()) . "<br>";
?>