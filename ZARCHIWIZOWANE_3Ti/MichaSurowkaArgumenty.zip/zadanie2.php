<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>F. z argumentem, zadanie 2, Michał Surówka</title>
</head>
<body>
<p>
Proszę podać liczbę
</p>
<form action="skrypty/script2.php" method="POST">
<input type="number" name="a"/>
<input type="submit" value="Oblicz silnię"/>
</form>

</body>
</html>