<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>F. z argumentem, zadanie 4, Michał Surówka</title>
</head>
<body>

<form action="skrypty/script4.php" method="POST"> <br />
Proszę podać liczbę: <br />
<input type="number" name="a"/> <br />
Proszę podać stopień potęgi: <br />
<input type="number" name="b"/> <br />
<input type="submit" value="Oblicz kwadrat liczby"/>
</form>

</body>
</html>