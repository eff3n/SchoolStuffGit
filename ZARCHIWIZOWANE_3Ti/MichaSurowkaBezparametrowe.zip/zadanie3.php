<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>F. Bezparametrowe, zadanie 3, Michał Surówka</title>
</head>
<body>
<form action="script.php" method="POST">
Podaj liczbę którą chcesz spierwiastkować <br />
<input type="number" name="liczba" />
<input type="submit" value="Spierwiastkuj"/>
</form>
</body>
</html>