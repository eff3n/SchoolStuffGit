<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>F. Bezparametrowe, zadanie 1, Michał Surówka</title>
</head>
<body>
Suma liczb 7 i 9 to:
<?php
function dodawanie()
{
	$a = 7;
	$b = 9;
	$c = $a+$b;
	echo $c;
}
dodawanie();
?>
</body>
</html>