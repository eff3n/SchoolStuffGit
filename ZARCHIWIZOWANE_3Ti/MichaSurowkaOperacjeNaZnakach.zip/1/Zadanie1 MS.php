<html>
<head>
    <title>Zadanie 1 MichałS</title>
    <style>
    </style>
</head>
<body>
    <form action="script1.php" method="POST">
    Wpisz swój anonimowy komentarz: <br />
    <input type=textbox name="a"/ style="width: 300px; height: 150px;"> 
    <input type=submit value="Opublikuj" />
    </form>
</body>
</html>