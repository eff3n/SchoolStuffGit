<?php
$drzewa = 'Dąb;Klon;Lipa;Sosna;Świerk;Topola';
$tablica = explode(";","$drzewa");
echo "$tablica[0] <br />";
echo "$tablica[1] <br />";
echo "$tablica[2] <br />";
echo "$tablica[3] <br />";
echo "$tablica[4] <br />";
echo $tablica[5];
?>