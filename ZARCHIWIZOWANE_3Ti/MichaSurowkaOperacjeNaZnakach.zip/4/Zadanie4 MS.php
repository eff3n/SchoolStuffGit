<html>
<head>
    <title>Zadanie  MichałS</title>
    <style>
    </style>
</head>
<body>
    <form action="script2.php" method="POST">
    Wpisz swoje imię: <br />
    <input type=textbox name="a"/> <br />
    Wpisz swoje nazwisko: <br />
    <input type=textbox name="b"/> <br />
    Wpisz swój komentarz: <br />
    <input type=textbox name="c"/> <br />
    <input type=submit value="Opublikuj" />
    </form>
</body>
</html>