<?php
$zwierzeta = array('Pies', 'Kot', 'Łoś', 'Koń', 'Krowa');
$wypisanie = implode(", ", $zwierzeta);
echo $wypisanie;
?>