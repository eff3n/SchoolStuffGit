<html>
<head>
    <title>Zadanie 4 MichałS</title>
</head>
<body>
    <form action="calc4.php" method="POST">
    Pierwsza liczba: <input type=number name="a"/> <br />
    <input type=submit value="Send" />
    </form>

</body>
</html>