<html>
<head>
    <title>Tablice, zadanie 1, Michał Surówka</title>
    <meta charset="UTF-8"/>
</head>
<body>
    <?php
    $tab = array('Poniedziałek', 'Wtorek', 'Środa', 'Czwartek', 'Piątek', 'Sobota', 'Niedziela');
    echo '<pre>';
	print_r($tab);
	echo '</pre>';
    ?>
</body>
</html>